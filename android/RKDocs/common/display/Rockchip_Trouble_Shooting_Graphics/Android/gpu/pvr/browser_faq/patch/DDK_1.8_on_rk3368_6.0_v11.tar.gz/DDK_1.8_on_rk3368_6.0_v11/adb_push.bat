adb remount

adb push system/vendor/lib/libPVRScopeServices.so system/vendor/lib/
adb push system/vendor/lib/libglslcompiler.so system/vendor/lib/
adb push system/vendor/lib/libIMGegl.so system/vendor/lib/
adb push system/vendor/lib/libpvrANDROID_WSEGL.so system/vendor/lib/
adb push system/vendor/lib/libsrv_um.so system/vendor/lib/
adb push system/vendor/lib/libusc.so system/vendor/lib/
adb push system/vendor/lib/egl/libGLESv1_CM_POWERVR_ROGUE.so system/vendor/lib/egl/
adb push system/vendor/lib/egl/libGLESv2_POWERVR_ROGUE.so system/vendor/lib/egl/
adb push system/vendor/lib/egl/libEGL_POWERVR_ROGUE.so system/vendor/lib/egl/
adb push system/vendor/lib/hw/gralloc.rk3368.so system/vendor/lib/hw/
adb push system/vendor/lib/hw/vulkan.rk3368.so system/vendor/lib/hw/
adb push system/vendor/lib/hw/memtrack.rk3368.so system/vendor/lib/hw/
adb push system/vendor/lib/libcreatesurface.so system/vendor/lib/

adb push system/vendor/lib/libufwriter.so system/vendor/lib/

adb push system/vendor/lib64/libsutu_display.so system/vendor/lib64/
adb push system/vendor/lib64/libPVRScopeServices.so system/vendor/lib64/
adb push system/vendor/lib64/libglslcompiler.so system/vendor/lib64/
adb push system/vendor/lib64/libIMGegl.so system/vendor/lib64/
adb push system/vendor/lib64/libpvrANDROID_WSEGL.so system/vendor/lib64/
adb push system/vendor/lib64/libsrv_um.so system/vendor/lib64/
adb push system/vendor/lib64/libusc.so system/vendor/lib64/
adb push system/vendor/lib64/egl/libGLESv1_CM_POWERVR_ROGUE.so system/vendor/lib64/egl/
adb push system/vendor/lib64/egl/libGLESv2_POWERVR_ROGUE.so system/vendor/lib64/egl/
adb push system/vendor/lib64/egl/libEGL_POWERVR_ROGUE.so system/vendor/lib64/egl/
adb push system/vendor/lib64/hw/gralloc.rk3368.so system/vendor/lib64/hw/
adb push system/vendor/lib64/hw/vulkan.rk3368.so system/vendor/lib64/hw/
adb push system/vendor/lib64/hw/memtrack.rk3368.so system/vendor/lib64/hw/
adb push system/vendor/lib64/libcreatesurface.so system/vendor/lib64/

adb push system/vendor/lib64/libufwriter.so system/vendor/lib64/

adb push system/vendor/bin/pvrsrvctl system/vendor/bin/
adb push system/vendor/bin/pvrdebug  system/vendor/bin/

adb push system/vendor/firmware/rgx.fw.signed system/vendor/firmware/
adb push system/vendor/firmware/rgx.fw.signed.5.9.1.46 system/vendor/firmware/

adb shell chmod 755  system/vendor/bin/pvrsrvctl
adb shell chmod 755 system/vendor/bin/pvrdebug
adb shell chmod 644 system/vendor/firmware/rgx.fw.signed

adb push hwc/lib64/hwcomposer.rk30board.so system/lib64/hw
adb push hwc/lib/hwcomposer.rk30board.so system/lib/hw
adb push libdrm/lib64/libdrm.so system/lib64
adb push libdrm/lib/libdrm.so system/lib
#adb push libdrm/lib64/libdrm_rockchip.so system/lib64
#adb push libdrm/lib/libdrm_rockchip.so system/lib

adb push system/lib/modules/pvrsrvkm.ko system/lib/modules/pvrsrvkm.ko
adb shell chmod 644 system/lib/modules/pvrsrvkm.ko

adb shell sync
