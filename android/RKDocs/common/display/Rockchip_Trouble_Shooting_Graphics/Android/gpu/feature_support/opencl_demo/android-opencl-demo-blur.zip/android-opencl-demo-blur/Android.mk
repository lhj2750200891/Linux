# Copyright (C) 2012 The Android Open Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_SRC_FILES:= gaussian.c \
                  args.c \
				  bitmap.c \
				  main.c

#LOCAL_SRC_FILES:= amix.c alsa_mixer.c
LOCAL_MODULE:= test_cl
LOCAL_SHARED_LIBRARIES := libc libcutils 
LOCAL_LDFLAGS += $(LOCAL_PATH)/libGLES_mali.so

LOCAL_CFLAGS += \
    -Wno-unknown-pragmas \
    -Wno-unused-variable
LOCAL_C_INCLUDES += \
	external/include \
	$(LOCAL_PATH)/include 

LOCAL_MODULE_TAGS:= debug
include $(BUILD_EXECUTABLE)
