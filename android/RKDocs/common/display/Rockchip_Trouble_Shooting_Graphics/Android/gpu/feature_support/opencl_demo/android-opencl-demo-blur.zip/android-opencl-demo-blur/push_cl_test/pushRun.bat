@adb root
@adb remount
@adb push image3.BMP system/bin/
@adb push kernel.cl system/bin/
@adb push test_cl system/bin/
@adb shell chmod 777 system/bin/test_cl
@adb shell cd system/bin;test_cl -i  /system/bin/image3.BMP -g 141 -s 69.8


 
